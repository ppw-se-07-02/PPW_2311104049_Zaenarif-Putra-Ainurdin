

<?php $__env->startSection('title', 'Detail Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Buku</h5>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('bukus.edit', $buku)); ?>" class="btn btn-warning">Edit</a>
            <a href="<?php echo e(route('bukus.index')); ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <tr>
                <th width="200">ID</th>
                <td><?php echo e($buku->id); ?></td>
            </tr>
            <tr>
                <th>Judul</th>
                <td><?php echo e($buku->judul); ?></td>
            </tr>
            <tr>
                <th>Penulis</th>
                <td><?php echo e($buku->penulis); ?></td>
            </tr>
            <tr>
                <th>Tahun Terbit</th>
                <td><?php echo e($buku->tahun_terbit); ?></td>
            </tr>
            <tr>
                <th>Penerbit</th>
                <td><?php echo e($buku->penerbit); ?></td>
            </tr>
            <tr>
                <th>Dibuat</th>
                <td><?php echo e($buku->created_at->format('d-m-Y H:i')); ?></td>
            </tr>
            <tr>
                <th>Diperbarui</th>
                <td><?php echo e($buku->updated_at->format('d-m-Y H:i')); ?></td>
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PPW_2311104049_Zaenarif-Putra-Ainurdin\Pertemuan13\Tugas13\resources\views/bukus/show.blade.php ENDPATH**/ ?>