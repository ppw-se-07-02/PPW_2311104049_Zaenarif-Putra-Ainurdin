

<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Daftar Buku</h5>
        <a href="<?php echo e(route('bukus.create')); ?>" class="btn btn-primary">
            + Tambah Buku
        </a>
    </div>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Tahun Terbit</th>
                    <th>Penerbit</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($buku->id); ?></td>
                    <td><?php echo e($buku->judul); ?></td>
                    <td><?php echo e($buku->penulis); ?></td>
                    <td><?php echo e($buku->tahun_terbit); ?></td>
                    <td><?php echo e($buku->penerbit); ?></td>
                    <td>
                        <a href="<?php echo e(route('bukus.show', $buku)); ?>" class="btn btn-sm btn-info">Lihat</a>
                        <a href="<?php echo e(route('bukus.edit', $buku)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('bukus.destroy', $buku)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" 
                                    onclick="return confirm('Hapus buku ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo e($bukus->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PPW_2311104049_Zaenarif-Putra-Ainurdin\Pertemuan13\Tugas13\resources\views/bukus/index.blade.php ENDPATH**/ ?>