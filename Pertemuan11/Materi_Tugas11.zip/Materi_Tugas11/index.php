<?php
header("Location: page.php?mod=beranda");
?>